﻿using Moq;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using PizzaExpress.Mgmnt.IService;

public class CustomerControllerTests
{
    private readonly Mock<ICustomerService> _mockCustomerService;
    private readonly CustomerController _controller;

    public CustomerControllerTests()
    {
        _mockCustomerService = new Mock<ICustomerService>();
        _controller = new CustomerController(_mockCustomerService.Object);
    }

    // Test GetCustomers() - Success
    [Fact]
    public async Task GetCustomers_ReturnsOk_WithListOfCustomers()
    {
        // Arrange
        var customers = new List<Customer>
        {
            new Customer { Id = 1, Name = "John Doe", Phone = "7412589630",Address="Adress Test - 1" },
            new Customer { Id = 2, Name = "Jane Doe", Phone = "7412589630",Address="Adress Test - 2"  }
        };
        _mockCustomerService.Setup(service => service.GetAllCustomers()).ReturnsAsync(customers);

        // Act
        var result = await _controller.GetCustomers();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnCustomers = Assert.IsType<List<Customer>>(okResult.Value);
        Assert.Equal(2, returnCustomers.Count);
    }

    // Test GetCustomer(id) - Valid ID
    [Fact]
    public async Task GetCustomer_ValidId_ReturnsOk()
    {
        // Arrange
        int customerId = 1;
        var customer = new Customer { Id = customerId, Name = "John Doe", Phone = "7412589630", Address = "Adress Test - 1" };
        _mockCustomerService.Setup(service => service.GetCustomerById(customerId)).ReturnsAsync(customer);

        // Act
        var result = await _controller.GetCustomer(customerId);

        // Assert
        var okResult = Assert.IsType<ActionResult<Customer>>(result);
        Assert.Equal(customerId, okResult.Value.Id);
    }

    // Test GetCustomer(id) - Invalid ID
    [Fact]
    public async Task GetCustomer_InvalidId_ReturnsNotFound()
    {
        // Arrange
        int customerId = 99;
        _mockCustomerService.Setup(service => service.GetCustomerById(customerId)).ReturnsAsync((Customer)null);

        // Act
        var result = await _controller.GetCustomer(customerId);

        // Assert
        Assert.IsType<NotFoundResult>(result.Result);
    }

    // Test CreateCustomer() - Valid Data
    [Fact]
    public async Task CreateCustomer_ValidData_ReturnsCreated()
    {
        // Arrange
        var customer = new Customer { Id = 1, Name = "New Customer", Phone = "7412589630", Address = "Adress Test - 1" };
        _mockCustomerService.Setup(service => service.CreateCustomer(customer)).Returns(Task.CompletedTask);

        // Act
        var result = await _controller.CreateCustomer(customer);

        // Assert
        var createdResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        var returnCustomer = Assert.IsType<Customer>(createdResult.Value);
        Assert.Equal(customer.Name, returnCustomer.Name);
    }

    //  Test CreateCustomer() - Null Data
    [Fact]
    public async Task CreateCustomer_NullData_ReturnsBadRequest()
    {
        // Act
        var result = await _controller.CreateCustomer(null);

        // Assert
        var badRequest = Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Equal("Invalid customer data.", badRequest.Value);
    }

    // Test UpdateCustomer() - Valid Data
    [Fact]
    public async Task UpdateCustomer_ValidData_ReturnsNoContent()
    {
        // Arrange
        int customerId = 1;
        var customer = new Customer { Id = customerId, Name = "Updated Name", Phone = "7412589630", Address = "Adress Test - 1" };

        _mockCustomerService.Setup(service => service.UpdateCustomer(customer)).Returns(Task.CompletedTask);

        // Act
        var result = await _controller.UpdateCustomer(customerId, customer);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    // Test UpdateCustomer() - Mismatched ID
    [Fact]
    public async Task UpdateCustomer_MismatchedId_ReturnsBadRequest()
    {
        // Arrange
        int customerId = 1;
        var customer = new Customer { Id = 2, Name = "Mismatched Customer", Phone = "7412589630", Address = "Adress Test - 1" };

        // Act
        var result = await _controller.UpdateCustomer(customerId, customer);

        // Assert
        Assert.IsType<BadRequestResult>(result);
    }

    //Test DeleteCustomer() - Valid ID
    [Fact]
    public async Task DeleteCustomer_ValidId_ReturnsNoContent()
    {
        // Arrange
        int customerId = 1;
        var customer = new Customer { Id = customerId, Name = "John Doe", Phone = "7412589630",Address="Adress Test - 1" };
        _mockCustomerService.Setup(service => service.GetCustomerById(customerId)).ReturnsAsync(customer);
        _mockCustomerService.Setup(service => service.DeleteCustomer(customerId)).Returns(Task.CompletedTask);

        // Act
        var result = await _controller.DeleteCustomer(customerId);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    //Test DeleteCustomer() - Invalid ID
    [Fact]
    public async Task DeleteCustomer_InvalidId_ReturnsNotFound()
    {
        // Arrange
        int customerId = 99;
        _mockCustomerService.Setup(service => service.GetCustomerById(customerId)).ReturnsAsync((Customer)null);

        // Act
        var result = await _controller.DeleteCustomer(customerId);

        // Assert
        Assert.IsType<NotFoundResult>(result);
    }
}
