﻿using Moq;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using PizzaExpress.Mgmnt.IService;
using System.Collections.Generic;
using System.Threading.Tasks;

public class PizzaControllerTests
{
    private readonly Mock<IPizzaService> _mockPizzaService;
    private readonly PizzaController _controller;

    public PizzaControllerTests()
    {
        _mockPizzaService = new Mock<IPizzaService>();
        _controller = new PizzaController(_mockPizzaService.Object);
    }

    //Test GetPizzas() - Success
    [Fact]
    public async Task GetPizzas_ReturnsOk_WithListOfPizzas()
    {
        // Arrange
        var pizzas = new List<Pizza>
        {
            new Pizza { Id = 1, Name = "Margherita", Description="desc 1", Price = 10.99M },
            new Pizza { Id = 2, Name = "Pepperoni", Description="desc 2" ,Price = 12.99M }
        };
        _mockPizzaService.Setup(service => service.GetAllPizzas()).ReturnsAsync(pizzas);

        // Act
        var result = await _controller.GetPizzas();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnPizzas = Assert.IsType<List<Pizza>>(okResult.Value);
        Assert.Equal(2, returnPizzas.Count);
    }

    // Test GetPizza(id) - Valid ID
    [Fact]
    public async Task GetPizza_ValidId_ReturnsOk()
    {
        // Arrange
        int pizzaId = 1;
        var pizza = new Pizza { Id = pizzaId, Name = "Margherita", Description = "desc 1", Price = 10.99M };
        _mockPizzaService.Setup(service => service.GetPizzaById(pizzaId)).ReturnsAsync(pizza);

        // Act
        var result = await _controller.GetPizza(pizzaId);

        // Assert
        var okResult = Assert.IsType<ActionResult<Pizza>>(result);
        Assert.Equal(pizzaId, okResult.Value.Id);
    }

    // Test GetPizza(id) - Invalid ID
    [Fact]
    public async Task GetPizza_InvalidId_ReturnsNotFound()
    {
        // Arrange
        int pizzaId = 99;
        _mockPizzaService.Setup(service => service.GetPizzaById(pizzaId)).ReturnsAsync((Pizza)null);

        // Act
        var result = await _controller.GetPizza(pizzaId);

        // Assert
        Assert.IsType<NotFoundResult>(result.Result);
    }

    // Test CreatePizza() - Valid Data
    [Fact]
    public async Task CreatePizza_ValidData_ReturnsCreated()
    {
        // Arrange
        var pizza = new Pizza { Id = 1, Name = "BBQ Chicken", Description = "desc 1", Price = 13.99M };
        _mockPizzaService.Setup(service => service.CreatePizza(pizza)).Returns(Task.CompletedTask);

        // Act
        var result = await _controller.CreatePizza(pizza);

        // Assert
        var createdResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        var returnPizza = Assert.IsType<Pizza>(createdResult.Value);
        Assert.Equal(pizza.Name, returnPizza.Name);
    }

    // Test CreatePizza() - Null Data
    [Fact]
    public async Task CreatePizza_NullData_ReturnsBadRequest()
    {
        // Act
        var result = await _controller.CreatePizza(null);

        // Assert
        var badRequest = Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Equal("Invalid customer data.", badRequest.Value);
    }

    // Test UpdatePizza() - Valid Data
    [Fact]
    public async Task UpdatePizza_ValidData_ReturnsNoContent()
    {
        // Arrange
        int pizzaId = 1;
        var pizza = new Pizza { Id = pizzaId, Name = "Veggie Supreme", Description = "desc 1", Price = 11.99M };

        _mockPizzaService.Setup(service => service.UpdatePizza(pizza)).Returns(Task.CompletedTask);

        // Act
        var result = await _controller.UpdatePizza(pizzaId, pizza);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    // Test UpdatePizza() - Mismatched ID
    [Fact]
    public async Task UpdatePizza_MismatchedId_ReturnsBadRequest()
    {
        // Arrange
        int pizzaId = 1;
        var pizza = new Pizza { Id = 2, Name = "Mismatched Pizza", Description = "desc 1", Price = 9.99M };

        // Act
        var result = await _controller.UpdatePizza(pizzaId, pizza);

        // Assert
        Assert.IsType<BadRequestResult>(result);
    }

    // Test DeletePizza() - Valid ID
    [Fact]
    public async Task DeletePizza_ValidId_ReturnsNoContent()
    {
        // Arrange
        int pizzaId = 1;
        var pizza = new Pizza { Id = pizzaId, Name = "Hawaiian", Description = "desc 1", Price = 10.99M };
        _mockPizzaService.Setup(service => service.GetPizzaById(pizzaId)).ReturnsAsync(pizza);
        _mockPizzaService.Setup(service => service.DeletePizza(pizzaId)).Returns(Task.CompletedTask);

        // Act
        var result = await _controller.DeletePizza(pizzaId);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    // Test DeletePizza() - Invalid ID
    [Fact]
    public async Task DeletePizza_InvalidId_ReturnsNotFound()
    {
        // Arrange
        int pizzaId = 99;
        _mockPizzaService.Setup(service => service.GetPizzaById(pizzaId)).ReturnsAsync((Pizza)null);

        // Act
        var result = await _controller.DeletePizza(pizzaId);

        // Assert
        Assert.IsType<NotFoundResult>(result);
    }
}
