﻿using Moq;
using Xunit;
using PizzaExpress.Mgmnt.IService;
using Microsoft.AspNetCore.Mvc;
using PizzaExpress.Mgmnt.Data.Access.Layer.Enum;

public class OrderControllerTests
{
    private readonly Mock<IOrderService> _mockOrderService;
    private readonly OrderController _controller;

    public OrderControllerTests()
    {
        // Initialize the mock service and controller
        _mockOrderService = new Mock<IOrderService>();
        _controller = new OrderController(_mockOrderService.Object);
    }

    [Fact]
    public async Task GetOrders_ReturnsOkResult_WithOrders()
    {
        // Arrange: Set up the mocked service to return a list of orders
        var orders = new List<Order> { new Order { Id = 1 }, new Order { Id = 2 } };
        _mockOrderService.Setup(service => service.GetAllOrders()).ReturnsAsync(orders);

        // Act: Call the GetOrders method on the controller
        var result = await _controller.GetOrders();

        // Assert: Verify that the controller returns an OkObjectResult with the list of orders
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnValue = Assert.IsType<List<Order>>(actionResult.Value);
        Assert.Equal(2, returnValue.Count);
    }


    [Fact]
    public async Task GetOrder_ValidId_ReturnsOkResult_WithOrder()
    {
        // Arrange
        int orderId = 1;
        var mockOrder = new Order { Id = orderId, OrderCode = "ORD123", Status = OrderStatus.Registered };

        _mockOrderService
            .Setup(service => service.GetOrderById(orderId))
            .ReturnsAsync(mockOrder);

        // Act
        var result = await _controller.GetOrder(orderId);

        // Assert
        var actionResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnValue = Assert.IsType<Order>(actionResult.Value); 
        Assert.Equal(orderId, returnValue.Id); 
    }

    [Fact]
    public async Task GetOrder_InvalidId_ReturnsNotFound()
    {
        // Arrange
        int orderId = 99;

        _mockOrderService
            .Setup(service => service.GetOrderById(orderId))
            .ReturnsAsync((Order)null); 

        // Act
        var result = await _controller.GetOrder(orderId);

        // Assert
        Assert.IsType<NotFoundResult>(result.Result); 
    }

    [Fact]
    public async Task CreateOrder_ValidOrder_ReturnsCreatedAtAction()
    {
        // Arrange
        var newOrder = new Order { Id = 1, Status = OrderStatus.Registered };

        _mockOrderService
            .Setup(service => service.CreateOrder(It.IsAny<Order>()))
            .Returns(Task.CompletedTask); 

        // Act
        var result = await _controller.CreateOrder(newOrder);

        // Assert
        var actionResult = Assert.IsType<CreatedAtActionResult>(result.Result); 
        var returnValue = Assert.IsType<Order>(actionResult.Value); 
        Assert.Equal(newOrder.Id, returnValue.Id);
        Assert.NotNull(returnValue.OrderCode); 
    }

    [Fact]
    public async Task CreateOrder_NullOrder_ReturnsBadRequest()
    {
        // Act
        var result = await _controller.CreateOrder(null);

        // Assert
        var actionResult = Assert.IsType<BadRequestObjectResult>(result.Result); 
        Assert.Equal("Invalid order data.", actionResult.Value); 
    }

    [Fact]
    public async Task CreateOrder_EnsuresOrderCodeIsGenerated()
    {
        // Arrange
        var newOrder = new Order { Id = 2, Status = OrderStatus.Registered };

        _mockOrderService
            .Setup(service => service.CreateOrder(It.IsAny<Order>()))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _controller.CreateOrder(newOrder);

        // Assert
        var actionResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        var returnValue = Assert.IsType<Order>(actionResult.Value);
        Assert.NotNull(returnValue.OrderCode); 
        Assert.Equal(8, returnValue.OrderCode.Length); 
    }

    [Fact]
    public async Task UpdateOrderStatus_ValidId_ReturnsNoContent()
    {
        // Arrange
        int orderId = 1;
        var existingOrder = new Order { Id = orderId, OrderCode = "ORD123", Status = OrderStatus.Registered };

        _mockOrderService
            .Setup(service => service.GetOrderById(orderId))
            .ReturnsAsync(existingOrder);

        _mockOrderService
            .Setup(service => service.UpdateOrder(existingOrder))
            .Returns(Task.CompletedTask);

        // Act
        var result = await _controller.UpdateOrderStatus(orderId, OrderStatus.Delivered);

        // Assert
        Assert.IsType<NoContentResult>(result);
        Assert.Equal(OrderStatus.Delivered, existingOrder.Status); 
    }

    [Fact]
    public async Task UpdateOrderStatus_InvalidId_ReturnsNotFound()
    {
        // Arrange
        int orderId = 99;

        _mockOrderService.Setup(service => service.GetOrderById(orderId))
            .ReturnsAsync((Order)null);

        // Act
        var result = await _controller.UpdateOrderStatus(orderId, OrderStatus.Delivered);

        // Assert
        Assert.IsType<NotFoundResult>(result); 
    }

    [Fact]
    public async Task DeleteOrder_ValidId_ReturnsNoContent()
    {
        // Arrange
        int orderId = 1;

        _mockOrderService
            .Setup(service => service.GetOrderById(orderId))
            .ReturnsAsync(new Order { Id = orderId });

        _mockOrderService
            .Setup(service => service.DeleteOrder(orderId))
            .Returns(Task.CompletedTask); 

        // Act
        var result = await _controller.DeleteOrder(orderId);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task DeleteOrder_InvalidId_ReturnsNotFound()
    {
        // Arrange
        int orderId = 99; 

        _mockOrderService
            .Setup(service => service.GetOrderById(orderId))
            .ReturnsAsync((Order)null); 

        // Act
        var result = await _controller.DeleteOrder(orderId);

        // Assert
        Assert.IsType<NotFoundResult>(result); 
    }

}
