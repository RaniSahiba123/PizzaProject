﻿using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

public class OrderItem
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int OrderId { get; set; } // Foreign key

    [ForeignKey("OrderId")]
    [JsonIgnore]
    public Order? Order { get; set; }

    [Required]
    public int PizzaId { get; set; } // Foreign key

    [ForeignKey("PizzaId")]
    public Pizza? Pizza { get; set; }

    [Required]
    [Range(1, 100, ErrorMessage = "Quantity must be between 1 and 100")]
    public int Quantity { get; set; }
}
