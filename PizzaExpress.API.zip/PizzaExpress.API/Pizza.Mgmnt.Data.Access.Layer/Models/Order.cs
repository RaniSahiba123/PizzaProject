﻿using PizzaExpress.Mgmnt.Data.Access.Layer.Enum;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Order
{
    [Key]
    public int Id { get; set; }

    [StringLength(7)]
    public string? OrderCode { get; set; } // Random 7-character code

    [Required]
    public int CustomerId { get; set; } // Foreign key

    [ForeignKey("CustomerId")]
    public Customer? Customer { get; set; }

    public List<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    [Required]
    public OrderStatus Status { get; set; } = OrderStatus.Registered; // Default status
}
