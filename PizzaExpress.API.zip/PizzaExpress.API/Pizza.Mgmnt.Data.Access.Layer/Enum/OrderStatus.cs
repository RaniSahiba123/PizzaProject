﻿namespace PizzaExpress.Mgmnt.Data.Access.Layer.Enum
{
    public enum OrderStatus
    {
        Registered,
        Preparation,
        ReadyForDelivery,
        Delivered
    }
}
