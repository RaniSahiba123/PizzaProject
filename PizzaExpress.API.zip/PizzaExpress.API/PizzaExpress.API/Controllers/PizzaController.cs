﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using PizzaExpress.Mgmnt.IService;
using PizzaExpress.Mgmnt.Service;

[Route("api/[controller]")]
[ApiController]
public class PizzaController : ControllerBase
{
    private readonly IPizzaService _pizzaService;

    public PizzaController(IPizzaService pizzaService)
    {
        _pizzaService = pizzaService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Pizza>>> GetPizzas()
    {
        return Ok(await _pizzaService.GetAllPizzas());
    }

    // GET a single pizza by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<Pizza>> GetPizza(int id)
    {
        var pizza = await _pizzaService.GetPizzaById(id);
        if (pizza == null) return NotFound();
        return pizza;
    }

    [HttpPost]
    public async Task<ActionResult<Pizza>> CreatePizza(Pizza pizza)
    {
        if (pizza == null)
        {
            return BadRequest("Invalid customer data.");
        }
        await _pizzaService.CreatePizza(pizza);
        return CreatedAtAction(nameof(GetPizza), new { id = pizza.Id }, pizza);
    }

    // PUT (Update an existing pizza)
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdatePizza(int id, Pizza pizza)
    {
        if (id != pizza.Id) return BadRequest();

        await _pizzaService.UpdatePizza(pizza);
        return NoContent();
    }

    // DELETE (Remove a pizza)
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeletePizza(int id)
    {
        var pizza = await _pizzaService.GetPizzaById(id);
        if (pizza == null) return NotFound();

        await _pizzaService.DeletePizza(id);
        return NoContent();
    }
}
