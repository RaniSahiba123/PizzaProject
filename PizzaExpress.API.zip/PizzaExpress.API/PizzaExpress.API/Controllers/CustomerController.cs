﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PizzaExpress.Mgmnt.Data.Access.Layer.Enum;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using PizzaExpress.Mgmnt.IService;
using PizzaExpress.Mgmnt.Service;
[Route("api/[controller]")]
[ApiController]
public class CustomerController : ControllerBase
{
    private readonly ICustomerService _customerService;

    public CustomerController(ICustomerService customerService)
    {
        _customerService = customerService;
    }

    // GET all customers
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Customer>>> GetCustomers()
    {
        return Ok(await _customerService.GetAllCustomers());
    }

    // GET a single customer by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<Customer>> GetCustomer(int id)
    {
        var customer = await _customerService.GetCustomerById(id);
        if (customer == null) return NotFound();
        return customer;
    }

    // POST (Create a new customer)
    [HttpPost]
    public async Task<ActionResult<Customer>> CreateCustomer(Customer customer)
    {
        if (customer == null)
        {
            return BadRequest("Invalid customer data.");
        }
        await _customerService.CreateCustomer(customer);
        return CreatedAtAction(nameof(GetCustomer), new { id = customer.Id }, customer);
    }

    // PUT (Update an existing customer)
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateCustomer(int id, Customer customer)
    {
        if (id != customer.Id) return BadRequest();
        await _customerService.UpdateCustomer(customer);
        return NoContent();
    }

    // DELETE (Remove a customer)
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCustomer(int id)
    {

        var customer = await _customerService.GetCustomerById(id);
        if (customer == null) return NotFound();

        await _customerService.DeleteCustomer(id);
        return NoContent();
    }
}
