﻿using Microsoft.AspNetCore.Mvc;
using PizzaExpress.Mgmnt.Data.Access.Layer.Enum;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using PizzaExpress.Mgmnt.IService;
[Route("api/[controller]")]
[ApiController]
public class OrderController : ControllerBase
{
    private readonly IOrderService _orderService;

    public OrderController(IOrderService orderService)
    {
        _orderService = orderService;
    }

    // GET all orders
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
    {
        return Ok(await _orderService.GetAllOrders());
    }

    // GET a single order by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<Order>> GetOrder(int id)
    {
        var order = await _orderService.GetOrderById(id);
        if (order == null) return NotFound();
        return Ok(order);
    }

    // POST (Create a new order)
    [HttpPost]
    public async Task<ActionResult<Order>> CreateOrder(Order order)
    {
        if (order == null)
        {
            return BadRequest("Invalid order data.");
        }

        order.OrderCode = GenerateOrderCode();
        await _orderService.CreateOrder(order);
        return CreatedAtAction(nameof(GetOrder), new { id = order.Id }, order);

    }

    // PUT (Update an order status)
    [HttpPut("{id}/status")]
    public async Task<IActionResult> UpdateOrderStatus(int id, OrderStatus status)
    {
        var order = await _orderService.GetOrderById(id);
        if (order == null) return NotFound();
        order.Status = status;
        await _orderService.UpdateOrder(order);
        return NoContent();
    }

    // DELETE (Remove an order)
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteOrder(int id)
    {
        var order = await _orderService.GetOrderById(id);
        if (order == null) return NotFound();

        await _orderService.DeleteOrder(id);
        return NoContent();
    }
    public static string GenerateOrderCode()
    {
        return Guid.NewGuid().ToString("N").Substring(0, 8).ToUpper();
    }

}
