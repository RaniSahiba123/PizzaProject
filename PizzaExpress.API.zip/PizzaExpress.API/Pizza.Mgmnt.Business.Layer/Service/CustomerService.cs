﻿
using PizzaExpress.Mgmnt.Data.Access.Layer.Interfaces;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using PizzaExpress.Mgmnt.IService;

namespace PizzaExpress.Mgmnt.Service
{
    public class CustomerService : ICustomerService
    {
        private readonly IGenericRepository<Customer> _customerRepository;

        public CustomerService(IGenericRepository<Customer> CustomerRepository)
        {
            _customerRepository = CustomerRepository;
        }

        public async Task<IEnumerable<Customer>> GetAllCustomers() => await _customerRepository.GetAllAsync();

        public async Task<Customer> GetCustomerById(int id) => await _customerRepository.GetByIdAsync(id);

        public async Task CreateCustomer(Customer Customer) => await _customerRepository.AddAsync(Customer);

        public async Task UpdateCustomer(Customer Customer) => await _customerRepository.UpdateAsync(Customer);

        public async Task DeleteCustomer(int id) => await _customerRepository.DeleteAsync(id);
    }
}
