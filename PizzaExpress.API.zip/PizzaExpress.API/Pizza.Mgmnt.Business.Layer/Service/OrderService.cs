﻿
using Microsoft.EntityFrameworkCore;
using PizzaExpress.Mgmnt.Data.Access.Layer.Interfaces;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using PizzaExpress.Mgmnt.IService;

namespace PizzaExpress.Mgmnt.Service
{
    public class OrderService : IOrderService
    {
        private readonly IGenericRepository<Order> _orderRepository;

        public OrderService(IGenericRepository<Order> orderRepository)
        {
            _orderRepository = orderRepository;
        }

        public async Task<Order> GetOrderById(int orderId)
        {
            var order= await _orderRepository.GetQueryable()
                .Where(o => o.Id == orderId)
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Pizza)
                .FirstOrDefaultAsync();

            return order;
        }


        public async Task<IEnumerable<Order>> GetAllOrders()
        {
            return await _orderRepository.GetQueryable()
                .Include(o=>o.Customer)
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Pizza)
                .ToListAsync();
        }
        public async Task CreateOrder(Order order) => await _orderRepository.AddAsync(order);

        public async Task UpdateOrder(Order order) => await _orderRepository.UpdateAsync(order);

        public async Task DeleteOrder(int id) => await _orderRepository.DeleteAsync(id);
    }
}
