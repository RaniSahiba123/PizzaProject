﻿
using PizzaExpress.Mgmnt.Data.Access.Layer.Interfaces;
using PizzaExpress.Mgmnt.Data.Access.Layer.Models;
using PizzaExpress.Mgmnt.IService;

namespace PizzaExpress.Mgmnt.Service
{
    public class PizzaService : IPizzaService
    {
        private readonly IGenericRepository<Pizza> _pizzaRepository;

        public PizzaService(IGenericRepository<Pizza> pizzaRepository)
        {
            _pizzaRepository = pizzaRepository;
        }

        public async Task<IEnumerable<Pizza>> GetAllPizzas() => await _pizzaRepository.GetAllAsync();

        public async Task<Pizza> GetPizzaById(int id) => await _pizzaRepository.GetByIdAsync(id);

        public async Task CreatePizza(Pizza pizza) => await _pizzaRepository.AddAsync(pizza);

        public async Task UpdatePizza(Pizza pizza) => await _pizzaRepository.UpdateAsync(pizza);

        public async Task DeletePizza(int id) => await _pizzaRepository.DeleteAsync(id);
    }
}
