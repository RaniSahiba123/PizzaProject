﻿

using PizzaExpress.Mgmnt.Data.Access.Layer.Models;

namespace PizzaExpress.Mgmnt.IService
{
    public interface IPizzaService
    {
        Task<IEnumerable<Pizza>> GetAllPizzas();
        Task<Pizza> GetPizzaById(int id);
        Task CreatePizza(Pizza pizza);
        Task UpdatePizza(Pizza pizza);
        Task DeletePizza(int id);
    }
}
