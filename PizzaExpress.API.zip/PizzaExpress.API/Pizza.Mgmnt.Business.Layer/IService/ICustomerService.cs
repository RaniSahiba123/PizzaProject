﻿

using PizzaExpress.Mgmnt.Data.Access.Layer.Models;

namespace PizzaExpress.Mgmnt.IService
{
    public interface ICustomerService
    {
        Task<IEnumerable<Customer>> GetAllCustomers();
        Task<Customer> GetCustomerById(int id);
        Task CreateCustomer(Customer order);
        Task UpdateCustomer(Customer order);
        Task DeleteCustomer(int id);
    }
}
